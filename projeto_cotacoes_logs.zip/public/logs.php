<?php
$logdir = __DIR__ . '/../logs';
$files=['app.log','errors.log','ia.log','db.log','auditoria.log'];
$sel=$_GET['f']??'app.log';
if(!in_array($sel,$files)) $sel='app.log';
$path="$logdir/$sel";
$lines=[];
if(file_exists($path)){
    $lines=array_slice(file($path), -500);
}
?>
<!doctype html><html><body>
<h2>Viewer de Logs</h2>
<form>
<select name="f">
<?php foreach($files as $f) echo "<option ".($f==$sel?"selected":"").">$f</option>"; ?>
</select>
<button>Ver</button>
</form>
<pre><?php foreach($lines as $l) echo htmlspecialchars($l); ?></pre>
</body></html>

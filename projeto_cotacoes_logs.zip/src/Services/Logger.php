<?php
class Logger {
    private static $dir = __DIR__ . '/../../logs/';

    private static function write($file, $msg) {
        $path = self::$dir . $file;
        $line = "[".date('Y-m-d H:i:s')."] ".$msg."\n";
        file_put_contents($path, $line, FILE_APPEND);
    }

    public static function app($m){ self::write('app.log',$m); }
    public static function error($m){ self::write('errors.log',$m); }
    public static function ia($m){ self::write('ia.log',$m); }
    public static function db($m){ self::write('db.log',$m); }
    public static function audit($m){ self::write('auditoria.log',$m); }
}
?>
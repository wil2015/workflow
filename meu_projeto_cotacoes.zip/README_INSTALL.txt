Instruções rápidas de instalação:

1. Copie os arquivos para o seu servidor web (por exemplo, /var/www/html/meu_projeto_cotacoes).
2. Ajuste config/config.php com as credenciais do banco e OpenAI.
3. Execute o SQL em sql/schema.sql no seu MySQL para criar o banco:
   mysql -u root -p < sql/schema.sql
4. Coloque arquivos .eml ou .txt em /emails.
5. Acesse no navegador: http://seu-servidor/meu_projeto_cotacoes/public/index.php
6. Clique em 'Processar e-mails' para importar as cotações.

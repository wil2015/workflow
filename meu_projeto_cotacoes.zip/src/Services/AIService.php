<?php

class AIService {

    private $apiKey;

    public function __construct()
    {
        $config = include __DIR__ . '/../../config/config.php';
        $this->apiKey = $config['openai']['api_key'];
    }

    public function extrairDadosCotacao($texto)
    {
        // WARNING: This example uses OpenAI API via HTTP. Replace model/name if needed.
        $functionSchema = [
            [
                'name' => 'extractQuotation',
                'description' => 'Extrai informações de cotação de fornecedores',
                'parameters' => [
                    'type' => 'object',
                    'properties' => [
                        'fornecedor' => ['type' => 'string'],
                        'itens' => [
                            'type' => 'array',
                            'items' => [
                                'type' => 'object',
                                'properties' => [
                                    'descricao' => ['type' => 'string'],
                                    'quantidade' => ['type' => 'string'],
                                    'preco' => ['type' => 'string']
                                ],
                                'required' => ['descricao']
                            ]
                        ]
                    ],
                    'required' => ['fornecedor']
                ]
            ]
        ];

        $payload = [
            'model' => 'gpt-4.1',
            'messages' => [
                ['role' => 'system', 'content' => 'Você extrai dados de cotações em texto e devolve JSON usando a função.'],
                ['role' => 'user', 'content' => $texto]
            ],
            'functions' => $functionSchema,
            'function_call' => 'auto'
        ];

        $ch = curl_init('https://api.openai.com/v1/chat/completions');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: ' . 'Bearer ' . $this->apiKey
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        $resp = curl_exec($ch);
        if ($resp === false) {
            throw new Exception('Erro na chamada à API: ' . curl_error($ch));
        }
        curl_close($ch);

        $json = json_decode($resp, true);

        if (!isset($json['choices'][0]['message']['function_call']['arguments'])) {
            // fallback: try parse plain message
            if (isset($json['choices'][0]['message']['content'])) {
                $maybe = $json['choices'][0]['message']['content'];
                $decoded = json_decode($maybe, true);
                if (is_array($decoded)) return $decoded;
            }
            throw new Exception('Resposta inesperada da API: ' . substr($resp,0,300));
        }

        return json_decode(
            $json['choices'][0]['message']['function_call']['arguments'], true
        );
    }
}

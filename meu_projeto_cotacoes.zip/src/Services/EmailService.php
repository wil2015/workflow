<?php
require_once __DIR__ . '/../Helpers/EmailFileHelper.php';

class EmailService {

    public function lerEmailsDoDiretorio()
    {
        $helper = new EmailFileHelper();
        return $helper->lerArquivosDeEmail();
    }
}

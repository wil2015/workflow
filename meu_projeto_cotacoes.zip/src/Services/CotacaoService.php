<?php
require_once __DIR__ . '/AIService.php';
require_once __DIR__ . '/../Repositories/FornecedorRepository.php';
require_once __DIR__ . '/../Repositories/ItemRepository.php';

class CotacaoService {

    private $ai;
    private $repoFornecedor;
    private $repoItem;

    public function __construct()
    {
        $this->ai = new AIService();
        $this->repoFornecedor = new FornecedorRepository();
        $this->repoItem = new ItemRepository();
    }

    public function extrairCotacaoDaIA($texto)
    {
        return $this->ai->extrairDadosCotacao($texto);
    }

    public function salvarCotacao($cotacao)
    {
        if (!isset($cotacao['fornecedor'])) {
            throw new Exception('Cotação sem fornecedor');
        }

        $idFornecedor = $this->repoFornecedor->salvar($cotacao['fornecedor']);

        if (!empty($cotacao['itens']) && is_array($cotacao['itens'])) {
            foreach ($cotacao['itens'] as $item) {
                $this->repoItem->salvar($idFornecedor, $item);
            }
        }
    }
}

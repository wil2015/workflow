<?php
require_once __DIR__ . '/../Services/EmailService.php';
require_once __DIR__ . '/../Services/CotacaoService.php';

class EmailController {

    public function processarEmails()
    {
        $emailService = new EmailService();
        $cotacaoService = new CotacaoService();

        $emails = $emailService->lerEmailsDoDiretorio();

        foreach ($emails as $email) {

            echo "Processando arquivo: {$email['arquivo']}\n";

            $texto = $email['conteudo'];

            try {
                $cotacao = $cotacaoService->extrairCotacaoDaIA($texto);

                if (!is_array($cotacao) || empty($cotacao['fornecedor'])) {
                    echo "  - IA não retornou cotação válida para {$email['arquivo']}\n";
                    continue;
                }

                $cotacaoService->salvarCotacao($cotacao);

                echo "  ✔ Cotação salva\n\n";
            } catch (Exception $e) {
                echo "  ERRO: " . $e->getMessage() . "\n\n";
            }
        }
    }
}

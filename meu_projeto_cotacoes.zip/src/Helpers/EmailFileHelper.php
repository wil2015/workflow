<?php

class EmailFileHelper {

    private $config;

    public function __construct()
    {
        $this->config = include __DIR__ . '/../../config/config.php';
    }

    private function extrairCorpoEmail($conteudo)
    {
        // separa cabeçalho do corpo
        $partes = preg_split("/\R\R/", $conteudo, 2);

        if (count($partes) < 2) {
            return $conteudo;
        }

        $cabecalho = $partes[0];
        $corpo = $partes[1];

        if (stripos($cabecalho, "quoted-printable") !== false) {
            $corpo = quoted_printable_decode($corpo);
        }

        if (stripos($cabecalho, "base64") !== false) {
            $corpo = base64_decode($corpo);
        }

        return $corpo;
    }

    public function lerArquivosDeEmail()
    {
        $dir = $this->config['email_dir'];

        if (!is_dir($dir)) {
            throw new Exception("Pasta de emails não existe: $dir");
        }

        $arquivos = scandir($dir);

        $emails = [];

        foreach ($arquivos as $arq) {

            if ($arq == '.' || $arq == '..') continue;

            $caminho = $dir . '/' . $arq;
            $conteudo_raw = file_get_contents($caminho);
            $corpo = $this->extrairCorpoEmail($conteudo_raw);

            $emails[] = [
                'arquivo'  => $arq,
                'conteudo' => $corpo
            ];
        }

        return $emails;
    }
}

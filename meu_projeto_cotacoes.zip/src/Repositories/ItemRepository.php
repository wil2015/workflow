<?php

class ItemRepository {

    private $db;

    public function __construct()
    {
        $conf = include __DIR__ . '/../../config/config.php';
        $this->db = new PDO(
            "mysql:host={$conf['db']['host']};dbname={$conf['db']['db']};charset=utf8",
            $conf['db']['user'],
            $conf['db']['pass']
        );
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function salvar($fornecedor_id, $item)
    {
        $descricao = isset($item['descricao']) ? $item['descricao'] : null;
        $quantidade = isset($item['quantidade']) ? $item['quantidade'] : null;
        $preco = isset($item['preco']) ? $item['preco'] : null;

        $stmt = $this->db->prepare("
            INSERT INTO itens_cotacao (fornecedor_id, descricao, quantidade, preco)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->execute([
            $fornecedor_id,
            $descricao,
            $quantidade,
            $preco
        ]);
    }
}

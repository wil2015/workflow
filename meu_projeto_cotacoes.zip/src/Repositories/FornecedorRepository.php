<?php

class FornecedorRepository {

    private $db;

    public function __construct()
    {
        $conf = include __DIR__ . '/../../config/config.php';
        $this->db = new PDO(
            "mysql:host={$conf['db']['host']};dbname={$conf['db']['db']};charset=utf8",
            $conf['db']['user'],
            $conf['db']['pass']
        );
        $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    public function salvar($nome)
    {
        // tenta encontrar se já existe para evitar duplicados
        $stmt = $this->db->prepare('SELECT id FROM fornecedores WHERE nome = ?');
        $stmt->execute([$nome]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) return $row['id'];

        $stmt = $this->db->prepare('INSERT INTO fornecedores (nome) VALUES (?)');
        $stmt->execute([$nome]);

        return $this->db->lastInsertId();
    }
}

-- Schema SQL para MySQL
CREATE DATABASE IF NOT EXISTS cotacoes CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cotacoes;

CREATE TABLE IF NOT EXISTS fornecedores (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255) UNIQUE
);

CREATE TABLE IF NOT EXISTS itens_cotacao (
  id INT AUTO_INCREMENT PRIMARY KEY,
  fornecedor_id INT,
  descricao VARCHAR(255),
  quantidade VARCHAR(50),
  preco DECIMAL(10,2),
  FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE CASCADE
);

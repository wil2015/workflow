<?php
return [
    'email_dir' => __DIR__ . '/../emails',
    'openai' => [
        'api_key' => 'SUA_API_KEY_AQUI'
    ],
    'db' => [
        'host' => '127.0.0.1',
        'db'   => 'cotacoes',
        'user' => 'root',
        'pass' => 'senha'
    ]
];

# Projeto: Meu Projeto Cotações

Este projeto em PHP lê arquivos de e-mail de um diretório (`/emails`), envia o conteúdo para uma função de IA (placeholder),
recebe JSON estruturado (cotação) e salva no banco MySQL. Inclui uma interface web simples para visualizar fornecedores e itens.

**Como usar**
1. Ajuste `config/config.php` com suas credenciais (DB e OpenAI API).
2. Coloque arquivos `.eml` ou `.txt` na pasta `emails/`.
3. Acesse `public/process.php` para processar (ou execute via CLI `php public/process.php`).
4. Abra `public/index.php` no navegador para visualizar as cotações.


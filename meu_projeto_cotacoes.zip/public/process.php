<?php
// Script para processar os arquivos de email (pode ser executado via web ou CLI)
require_once __DIR__ . '/../src/Controllers/EmailController.php';

$controller = new EmailController();
$controller->processarEmails();

echo "\nProcessamento finalizado.\n";

<?php
// Interface web simples para listar fornecedores e itens
$config = include __DIR__ . '/../config/config.php';

try {
    $conf = $config['db'];
    $pdo = new PDO("mysql:host={$conf['host']};dbname={$conf['db']};charset=utf8", $conf['user'], $conf['pass']);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    echo '<h2>Erro ao conectar no banco:</h2><pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
    exit;
}

// Busca fornecedores e itens
$stmt = $pdo->query('SELECT f.id, f.nome, i.id AS item_id, i.descricao, i.quantidade, i.preco
                     FROM fornecedores f
                     LEFT JOIN itens_cotacao i ON i.fornecedor_id = f.id
                     ORDER BY f.id, i.id');

$data = [];
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $fid = $row['id'];
    if (!isset($data[$fid])) {
        $data[$fid] = [
            'nome' => $row['nome'],
            'itens' => []
        ];
    }
    if ($row['item_id']) {
        $data[$fid]['itens'][] = [
            'descricao' => $row['descricao'],
            'quantidade' => $row['quantidade'],
            'preco' => $row['preco']
        ];
    }
}
?>
<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8"/>
<title>Cotações - Painel</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;padding:20px}
.card{border:1px solid #ddd;padding:12px;margin:10px;border-radius:8px}
h2{margin:0 0 10px 0}
table{width:100%;border-collapse:collapse}
th,td{padding:8px;border:1px solid #eee;text-align:left}
.small{font-size:0.9em;color:#666}
.process-btn{display:inline-block;padding:8px 12px;background:#28a745;color:#fff;border-radius:6px;text-decoration:none}
</style>
</head>
<body>
<h1>Painel de Cotações</h1>
<p class="small">Clique em <strong>Processar e-mails</strong> para ler a pasta <code>emails/</code> e salvar no banco.</p>
<p><a class="process-btn" href="process.php">Processar e-mails</a></p>

<?php if (empty($data)): ?>
    <p>Nenhuma cotação encontrada.</p>
<?php else: ?>
    <?php foreach ($data as $fid => $f): ?>
        <div class="card">
            <h2><?php echo htmlspecialchars($f['nome']); ?></h2>
            <?php if (empty($f['itens'])): ?>
                <p class="small">Nenhum item registrado.</p>
            <?php else: ?>
                <table>
                    <thead><tr><th>Descrição</th><th>Quantidade</th><th>Preço</th></tr></thead>
                    <tbody>
                    <?php foreach ($f['itens'] as $it): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($it['descricao']); ?></td>
                            <td><?php echo htmlspecialchars($it['quantidade']); ?></td>
                            <td><?php echo htmlspecialchars($it['preco']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</body>
</html>
